<?php
/**
 * Plugin Name: Bloom & Veg - Shop Category Bar
 * Description: Adds a horizontal product category bar on WooCommerce shop pages.
 * Version: 0.5.4
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
	exit;
}

// Guard against the plugin being loaded twice (e.g. duplicate install folders).
if (defined('BV_SHOP_CATEGORY_BAR_LOADED')) {
	return;
}
define('BV_SHOP_CATEGORY_BAR_LOADED', true);

define('BV_SHOP_CATEGORY_BAR_VERSION', '0.5.4');

define('BV_SHOP_CATEGORY_BAR_TERMS', [
	// label => slug
	'Veg' => 'veg',
	'Fruit' => 'fruit',
	'Meat' => 'meat',
	'Drinks' => 'drinks',
	'Compost & Topsoil' => 'compost-topsoil',
	'Cakes' => 'cakes',
	'Sweets & Biscuits' => 'sweets-biscuits',
]);

define('BV_SHOP_CATEGORY_BAR_NAV', [
	[
		'label' => 'Veg & Fruit',
		'slug' => 'veg-fruit',
		'children' => ['veg', 'fruit'],
	],
	[
		'label' => 'Meat',
		'slug' => 'meat',
	],
	[
		'label' => 'Drinks',
		'slug' => 'drinks',
	],
	[
		'label' => 'Compost & Topsoil',
		'slug' => 'compost-topsoil',
	],
	[
		'label' => 'Cakes',
		'slug' => 'cakes',
	],
	[
		'label' => 'Sweets & Biscuits',
		'slug' => 'sweets-biscuits',
	],
]);

define('BV_SHOP_CATEGORY_BAR_ASSET_CSS', 'assets/css/bv-shop-category-bar.css');
define('BV_SHOP_CATEGORY_BAR_ASSET_JS', 'assets/js/bv-shop-category-bar.js');

function bv_shop_category_bar_is_shop_context(): bool {
	if (is_admin()) {
		return false;
	}

	// Fallback for sites where the "Shop" is implemented as a normal WP page.
	if (function_exists('is_page') && is_page('shop')) {
		return true;
	}

	// If WooCommerce isn't active, we don't render (except the fallback above).
	if (!class_exists('WooCommerce')) {
		return false;
	}

	// More robust checks that work even if some Woo conditional helpers aren't available.
	if (function_exists('is_post_type_archive') && is_post_type_archive('product')) {
		return true;
	}
	if (function_exists('is_tax') && is_tax('product_cat')) {
		return true;
	}

	if (function_exists('is_shop') && is_shop()) {
		return true;
	}
	if (function_exists('is_product_category') && is_product_category()) {
		return true;
	}
	if (function_exists('is_product') && is_product()) {
		return true;
	}

	return false;
}

function bv_shop_category_bar_can_render(): bool {
	if (!is_admin()) {
		return true;
	}
	// admin-ajax.php runs in an "admin" context; allow rendering for our JSON endpoint.
	return function_exists('wp_doing_ajax') ? wp_doing_ajax() : (defined('DOING_AJAX') && DOING_AJAX);
}

function bv_shop_category_bar_ensure_terms_exist(): void {
	if (!function_exists('taxonomy_exists') || !taxonomy_exists('product_cat')) {
		return;
	}

	foreach (BV_SHOP_CATEGORY_BAR_TERMS as $label => $slug) {
		$existing = get_term_by('slug', (string) $slug, 'product_cat');
		if ($existing instanceof WP_Term) {
			continue;
		}

		wp_insert_term((string) $label, 'product_cat', [
			'slug' => (string) $slug,
		]);
	}
}

register_activation_hook(__FILE__, static function (): void {
	bv_shop_category_bar_ensure_terms_exist();
});

add_action('init', static function (): void {
	// In case categories are created later, ensure they exist once taxonomy is available.
	bv_shop_category_bar_ensure_terms_exist();
}, 20);

add_action('wp_ajax_bv_shop_catbar', static function (): void {
	if (is_admin() && !wp_doing_ajax()) {
		wp_send_json_error(['message' => 'invalid_context'], 400);
	}
	$html = bv_shop_category_bar_render();
	if (!headers_sent()) {
		header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
		header('Pragma: no-cache');
		header('Expires: 0');
	}
	wp_send_json_success([
		'html' => $html,
		'version' => BV_SHOP_CATEGORY_BAR_VERSION,
	]);
});

add_action('wp_ajax_nopriv_bv_shop_catbar', static function (): void {
	$html = bv_shop_category_bar_render();
	if (!headers_sent()) {
		header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
		header('Pragma: no-cache');
		header('Expires: 0');
	}
	wp_send_json_success([
		'html' => $html,
		'version' => BV_SHOP_CATEGORY_BAR_VERSION,
	]);
});

add_action('wp_enqueue_scripts', static function (): void {
	if (!bv_shop_category_bar_can_render()) {
		return;
	}

	$css_path = plugin_dir_path(__FILE__) . BV_SHOP_CATEGORY_BAR_ASSET_CSS;
	$js_path = plugin_dir_path(__FILE__) . BV_SHOP_CATEGORY_BAR_ASSET_JS;
	$css_ver = BV_SHOP_CATEGORY_BAR_VERSION;
	$js_ver = BV_SHOP_CATEGORY_BAR_VERSION;
	if (file_exists($css_path)) {
		$css_ver .= '-' . (string) filemtime($css_path);
	}
	if (file_exists($js_path)) {
		$js_ver .= '-' . (string) filemtime($js_path);
	}

	wp_enqueue_style(
		'bv-shop-category-bar',
		plugins_url(BV_SHOP_CATEGORY_BAR_ASSET_CSS, __FILE__),
		[],
		$css_ver
	);

	wp_enqueue_script(
		'bv-shop-category-bar',
		plugins_url(BV_SHOP_CATEGORY_BAR_ASSET_JS, __FILE__),
		[],
		$js_ver,
		false
	);

	wp_localize_script('bv-shop-category-bar', 'BVShopCatBar', [
		'ajaxUrl' => admin_url('admin-ajax.php'),
	]);
}, 20);

add_action('wp_footer', static function (): void {
	if (is_admin()) {
		return;
	}

	// Move the bar under the header on themes that output it elsewhere.
	?>
	<script>
	(function(){
	  function place(){
	    var bar=document.getElementById('bv-shop-catbar');
	    if(!bar) return;
	    var header=document.querySelector('.site-header');
	    if(!header) return;
	    if(header.nextElementSibling!==bar){
	      header.insertAdjacentElement('afterend', bar);
	    }
	    try{
	      var pos=window.getComputedStyle(header).position;
	      if(pos==='fixed'){
	        bar.style.marginTop = header.getBoundingClientRect().height + 'px';
	      } else {
	        bar.style.marginTop = '';
	      }
	    }catch(e){}
	  }
	  try{ place(); }catch(e){}
	  if(document.readyState==='loading'){
	    document.addEventListener('DOMContentLoaded', place);
	  }
	  window.addEventListener('load', place);
	  window.addEventListener('resize', place);
	  setTimeout(place, 50);
	  setTimeout(place, 250);
	  setTimeout(place, 1000);
	})();
	</script>
	<?php
}, 20);

add_action('wp_head', static function (): void {
	if (is_admin()) {
		return;
	}

	// Some performance/minify setups strip HTML comments. Use a meta tag too.
	echo "\n<meta name=\"bv-shop-category-bar\" content=\"" . esc_attr(BV_SHOP_CATEGORY_BAR_VERSION) . "\" />\n";
	echo "\n<!-- bv-shop-category-bar " . esc_html(BV_SHOP_CATEGORY_BAR_VERSION) . " (active) -->\n";
}, 999);

add_action('send_headers', static function (): void {
	if (is_admin()) {
		return;
	}

	if (!function_exists('header') || headers_sent()) {
		return;
	}

	header('X-BV-Shop-Category-Bar: ' . BV_SHOP_CATEGORY_BAR_VERSION);
}, 20);

function bv_shop_category_bar_render(): string {
	if (!bv_shop_category_bar_can_render()) {
		return '';
	}

	// If WooCommerce is active, ensure terms exist.
	bv_shop_category_bar_ensure_terms_exist();

	$current_slug = '';
	if (function_exists('is_product_category') && is_product_category()) {
		$queried = get_queried_object();
		if ($queried instanceof WP_Term) {
			$current_slug = (string) $queried->slug;
		}
	}
	if ($current_slug === '' && isset($_SERVER['REQUEST_URI'])) {
		$path = (string) wp_parse_url((string) $_SERVER['REQUEST_URI'], PHP_URL_PATH);
		foreach (BV_SHOP_CATEGORY_BAR_TERMS as $label => $slug) {
			if (strpos($path, '/product-category/' . (string) $slug) !== false) {
				$current_slug = (string) $slug;
				break;
			}
		}
	}

	$items = [];
	foreach (BV_SHOP_CATEGORY_BAR_NAV as $nav_item) {
		$label = isset($nav_item['label']) ? (string) $nav_item['label'] : '';
		$slug = isset($nav_item['slug']) ? (string) $nav_item['slug'] : '';
		$child_slugs = isset($nav_item['children']) && is_array($nav_item['children']) ? $nav_item['children'] : [];

		if ($label === '' || $slug === '') {
			continue;
		}

		// Grouped item: manual dropdown (Veg + Fruit) and active when either child is active.
		if (!empty($child_slugs)) {
			$children = [];
			$first_url = '';
			foreach ($child_slugs as $child_slug) {
				$child_slug = (string) $child_slug;
				$child_label = '';
				foreach (BV_SHOP_CATEGORY_BAR_TERMS as $term_label => $term_slug) {
					if ((string) $term_slug === $child_slug) {
						$child_label = (string) $term_label;
						break;
					}
				}
				if ($child_label === '') {
					$child_label = ucfirst(str_replace('-', ' ', $child_slug));
				}

				$url = home_url('/product-category/' . $child_slug . '/');
				if (function_exists('taxonomy_exists') && taxonomy_exists('product_cat')) {
					$child_term = get_term_by('slug', $child_slug, 'product_cat');
					if ($child_term instanceof WP_Term) {
						$child_link = get_term_link($child_term, 'product_cat');
						if (!is_wp_error($child_link)) {
							$url = (string) $child_link;
						}
					}
				}

				if ($first_url === '') {
					$first_url = (string) $url;
				}

				$children[] = [
					'label' => $child_label,
					'url' => (string) $url,
				];
			}

			$is_active = $current_slug !== '' && in_array($current_slug, array_map('strval', $child_slugs), true);

			$items[] = [
				'label' => $label,
				'url' => $first_url !== '' ? $first_url : home_url('/shop/'),
				'slug' => $slug,
				'active' => $is_active,
				'children' => $children,
				'has_menu' => !empty($children),
			];
			continue;
		}

		$link = '';
		$term = null;
		if (function_exists('taxonomy_exists') && taxonomy_exists('product_cat')) {
			$term = get_term_by('slug', (string) $slug, 'product_cat');
			if ($term instanceof WP_Term) {
				$term_link = get_term_link($term, 'product_cat');
				if (!is_wp_error($term_link)) {
					$link = (string) $term_link;
				}
			}

			if ($link === '' && function_exists('wp_insert_term')) {
				// Attempt to create on the fly if it doesn't exist yet.
				$created = wp_insert_term((string) $label, 'product_cat', ['slug' => (string) $slug]);
				if (!is_wp_error($created) && isset($created['term_id'])) {
					$maybe_term = get_term((int) $created['term_id'], 'product_cat');
					if ($maybe_term instanceof WP_Term) {
						$term_link = get_term_link($maybe_term, 'product_cat');
						if (!is_wp_error($term_link)) {
							$link = (string) $term_link;
						}
					}
				}
			}
		}

		if ($link === '') {
			// Fallback URL so the bar still renders even if WooCommerce isn't detected.
			$link = home_url('/product-category/' . (string) $slug . '/');
		}

		// Always include "All {Category}" as the first menu item.
		$children = [
			[
				'label' => 'All ' . (string) $label,
				'url' => (string) $link,
			],
		];
		$has_real_children = false;
		if (isset($term) && $term instanceof WP_Term && function_exists('get_terms')) {
			$child_terms = get_terms([
				'taxonomy' => 'product_cat',
				'hide_empty' => false,
				'parent' => (int) $term->term_id,
				'orderby' => 'name',
				'order' => 'ASC',
			]);
			if (!is_wp_error($child_terms) && is_array($child_terms)) {
				foreach ($child_terms as $child) {
					if (!($child instanceof WP_Term)) {
						continue;
					}
					$child_link = get_term_link($child, 'product_cat');
					if (is_wp_error($child_link)) {
						continue;
					}
					$has_real_children = true;
					$children[] = [
						'label' => (string) $child->name,
						'url' => (string) $child_link,
					];
				}
			}
		}

		$items[] = [
			'label' => (string) $label,
			'url' => (string) $link,
			'slug' => (string) $slug,
			'active' => $current_slug === (string) $slug,
			'children' => $children,
			'has_menu' => $has_real_children,
		];
	}

	if (empty($items)) {
		return '';
	}

	ob_start();
	?>
	<nav id="bv-shop-catbar" class="bv-shop-catbar" aria-label="Shop categories">
		<div class="bv-shop-catbar__inner">
			<?php foreach ($items as $item) : ?>
				<div class="bv-shop-catbar__item">
					<div class="bv-shop-catbar__pill<?php echo !empty($item['active']) ? ' is-active' : ''; ?>">
						<a class="bv-shop-catbar__link" href="<?php echo esc_url($item['url']); ?>">
							<?php echo esc_html($item['label']); ?>
						</a>
						<?php if (!empty($item['has_menu'])) : ?>
							<button class="bv-shop-catbar__toggle" type="button" aria-label="<?php echo esc_attr('Open ' . (string) $item['label'] . ' menu'); ?>" aria-expanded="false">
								<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
									<path d="M6 9l6 6 6-6" />
								</svg>
							</button>
							<div class="bv-shop-catbar__menu" role="menu" aria-label="<?php echo esc_attr($item['label']); ?> menu">
								<?php foreach ($item['children'] as $child) : ?>
									<a role="menuitem" href="<?php echo esc_url($child['url']); ?>"><?php echo esc_html($child['label']); ?></a>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</nav>
	<?php
	return (string) ob_get_clean();
}

function bv_shop_category_bar_output_once(): void {
	static $done = false;
	if ($done) {
		return;
	}
	$done = true;

	if (!bv_shop_category_bar_can_render()) {
		return;
	}

	$markup = bv_shop_category_bar_render();
	if ($markup === '') {
		return;
	}

	$GLOBALS['bv_shop_category_bar_rendered'] = true;
	echo $markup;
}

add_action('woocommerce_before_main_content', 'bv_shop_category_bar_output_once', 5);
add_action('woocommerce_before_shop_loop', 'bv_shop_category_bar_output_once', 5);
add_action('woocommerce_before_single_product', 'bv_shop_category_bar_output_once', 5);

// Note: do not output in wp_body_open() on this theme; it appears above the sticky
// header and may get covered. We output in the footer and move it under the header.

// Fallback for themes that don't call WooCommerce hooks on non-shop pages.
add_action('wp_footer', 'bv_shop_category_bar_output_once', 1);



add_action('wp_footer', static function (): void {
	if (is_admin()) {
		return;
	}

	// Another non-comment marker for debugging (hidden).
	echo "\n<div id=\"bv-shop-category-bar-active\" data-version=\"" . esc_attr(BV_SHOP_CATEGORY_BAR_VERSION) . "\" style=\"display:none!important\"></div>\n";
}, 999);

add_action('admin_notices', static function (): void {
	if (!current_user_can('manage_options')) {
		return;
	}

	$screen = function_exists('get_current_screen') ? get_current_screen() : null;
	$screen_id = is_object($screen) && isset($screen->id) ? (string) $screen->id : '';
	if (!in_array($screen_id, ['plugins', 'dashboard'], true)) {
		return;
	}

	echo '<div class="notice notice-info"><p><strong>BV Shop Category Bar</strong> is active (v' . esc_html(BV_SHOP_CATEGORY_BAR_VERSION) . ').</p></div>';
});
