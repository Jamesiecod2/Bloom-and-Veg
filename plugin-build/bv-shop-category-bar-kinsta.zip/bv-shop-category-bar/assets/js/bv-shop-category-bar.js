(function(){
  function placeBarUnderHeader(){
    try{
      var bar = document.getElementById('bv-shop-catbar');
      if(!bar) return;
      var header = document.querySelector('.site-header');
      if(!header) return;

      try{
        var headerHeight = header.getBoundingClientRect().height;
        if(headerHeight && headerHeight > 0){
          document.documentElement.style.setProperty('--bv-site-header-h', headerHeight + 'px');
        }
      }catch(e){}

      if(header.nextElementSibling !== bar){
        header.insertAdjacentElement('afterend', bar);
      }

      try{
        var pos = window.getComputedStyle(header).position;
        if(pos === 'fixed'){
          bar.style.marginTop = header.getBoundingClientRect().height + 'px';
        } else {
          bar.style.marginTop = '';
        }
      }catch(e){}
    }catch(e){}
  }

  function ensureBarPresent(){
    try{
      if(document.getElementById('bv-shop-catbar')) return;
      if(!window.fetch) return;

      var ajaxUrl = (window.BVShopCatBar && window.BVShopCatBar.ajaxUrl) ? window.BVShopCatBar.ajaxUrl : '';
      if(!ajaxUrl) return;
      var url = ajaxUrl + (ajaxUrl.indexOf('?') >= 0 ? '&' : '?') + 'action=bv_shop_catbar';

      // Fetch markup via admin-ajax to survive full-page caches.
      fetch(url, { credentials: 'same-origin' })
        .then(function(r){ return r.ok ? r.json() : null; })
        .then(function(data){
          var payload = data && data.data ? data.data : data;
          if(!payload || !payload.html) return;
          if(document.getElementById('bv-shop-catbar')) return;

          var wrap = document.createElement('div');
          wrap.innerHTML = payload.html;
          var bar = wrap.querySelector('#bv-shop-catbar');
          if(!bar) return;

          var header = document.querySelector('.site-header');
          if(header && header.parentNode){
            header.insertAdjacentElement('afterend', bar);
          } else {
            document.body.insertBefore(bar, document.body.firstChild);
          }

          placeBarUnderHeader();
        })
        .catch(function(){});
    }catch(e){}
  }

  function closest(el, sel){
    while(el && el.nodeType===1){
      if(el.matches(sel)) return el;
      el = el.parentElement;
    }
    return null;
  }

  function closeAll(root){
    var items = (root || document).querySelectorAll('.bv-shop-catbar__item.is-open');
    items.forEach(function(item){
      item.classList.remove('is-open');
      var btn = item.querySelector('.bv-shop-catbar__toggle');
      if(btn) btn.setAttribute('aria-expanded','false');
    });
  }

  function onToggleClick(e){
    var btn = e.target.closest('.bv-shop-catbar__toggle');
    if(!btn) return;

    e.preventDefault();
    e.stopPropagation();

    var item = closest(btn, '.bv-shop-catbar__item');
    if(!item) return;

    var isOpen = item.classList.contains('is-open');
    closeAll(document);
    if(!isOpen){
      item.classList.add('is-open');
      btn.setAttribute('aria-expanded','true');
    }
  }

  function onLinkClick(e){
    try{
      var link = e.target.closest('.bv-shop-catbar__link');
      if(!link) return;

      var item = closest(link, '.bv-shop-catbar__item');
      if(!item) return;

      // Only intercept clicks for items that actually have a menu.
      var menu = item.querySelector('.bv-shop-catbar__menu');
      if(!menu) return;

      var isOpen = item.classList.contains('is-open');
      if(!isOpen){
        e.preventDefault();
        e.stopPropagation();
        closeAll(document);
        item.classList.add('is-open');
      }
    }catch(e2){}
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded', ensureBarPresent);
    document.addEventListener('DOMContentLoaded', placeBarUnderHeader);
  } else {
    ensureBarPresent();
    placeBarUnderHeader();
  }

  try{
    placeBarUnderHeader();
    setTimeout(placeBarUnderHeader, 50);
    setTimeout(placeBarUnderHeader, 250);
    setTimeout(placeBarUnderHeader, 1000);
    window.addEventListener('load', placeBarUnderHeader);
    window.addEventListener('resize', placeBarUnderHeader);
  }catch(e){}

  document.addEventListener('click', onToggleClick);
  document.addEventListener('click', onLinkClick);
  document.addEventListener('click', function(e){
    if(!closest(e.target, '.bv-shop-catbar')){
      closeAll(document);
    }
  }, true);
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeAll(document);
  });
})();
